import{S as c}from"./sweetalert2.all.cb3a3f57.js";import{x as a}from"./index.267ebe00.js";const p={__name:"ErrorComponent",props:{errors:{type:[Object],default:()=>{}}},setup(s){const o=s;return a(()=>o.errors,t=>{var e;let r=' <ul class="text-left list-disc text-red-500 mb-2 px-2 text-base"> ';if((e=Object.keys(t))!=null&&e.length){for(const l in t)r+=`<li> ${t[l]} </li>`;r+="</ul>",c.fire({icon:"",title:"Correct Please!",html:`
                ${r}
                        `,customClass:"swal-width"})}}),(t,r)=>null}};export{p as _};
