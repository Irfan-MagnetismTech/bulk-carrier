import{_}from"./index.267ebe00.js";const e={__name:"show",setup(s){return(t,r)=>null}};var o=_(e,[["__scopeId","data-v-c555390c"]]);export{o as default};
