var n={exports:{}};/*!
 * bytes
 * Copyright(c) 2012-2014 TJ Holowaychuk
 * Copyright(c) 2015 Jed Watson
 * MIT Licensed
 */n.exports=B;n.exports.format=b;n.exports.parse=l;var x=/\B(?=(\d{3})+(?!\d))/g,g=/(?:\.0*|(\.[^0]+)0+)$/,i={b:1,kb:1<<10,mb:1<<20,gb:1<<30,tb:Math.pow(1024,4),pb:Math.pow(1024,5)},v=/^((-|\+)?(\d+(?:\.\d+)?)) *(kb|mb|gb|tb|pb)$/i;function B(r,e){return typeof r=="string"?l(r):typeof r=="number"?b(r,e):null}function b(r,e){if(!Number.isFinite(r))return null;var a=Math.abs(r),s=e&&e.thousandsSeparator||"",p=e&&e.unitSeparator||"",o=e&&e.decimalPlaces!==void 0?e.decimalPlaces:2,m=Boolean(e&&e.fixedDecimals),t=e&&e.unit||"";(!t||!i[t.toLowerCase()])&&(a>=i.pb?t="PB":a>=i.tb?t="TB":a>=i.gb?t="GB":a>=i.mb?t="MB":a>=i.kb?t="KB":t="B");var c=r/i[t.toLowerCase()],f=c.toFixed(o);return m||(f=f.replace(g,"$1")),s&&(f=f.split(".").map(function(u,d){return d===0?u.replace(x,s):u}).join(".")),f+p+t}function l(r){if(typeof r=="number"&&!isNaN(r))return r;if(typeof r!="string")return null;var e=v.exec(r),a,s="b";return e?(a=parseFloat(e[1]),s=e[4].toLowerCase()):(a=parseInt(r,10),s="b"),isNaN(a)?null:Math.floor(i[s]*a)}var h=n.exports;export{h as b};
