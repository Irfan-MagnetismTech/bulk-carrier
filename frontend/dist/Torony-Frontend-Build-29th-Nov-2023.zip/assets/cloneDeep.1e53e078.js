import{_ as o}from"./_baseClone.d5d05863.js";var r=o,a=1,n=4;function _(e){return r(e,a|n)}var c=_;export{c};
